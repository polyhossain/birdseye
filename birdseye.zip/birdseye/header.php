<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
        wp_head();
    ?>
</head>
<body <?php body_class(); ?>>
    <?php 
        wp_body_open(); 
    ?>
    <a class="skip-link screen-reader-text" href="#birdseye-content">
        <?php 
            _e( 'Skip to content', 'birdseye' ); 
        ?>
    </a>

    <header class="bg-cyan-900 text-white">
        <div class="w-8/12 mx-auto py-3 flex justify-between items-center">
            <a href="<?php echo home_url(); ?>" class="text-2xl">
                <?php 
                    bloginfo('name'); 
                ?>
            </a>
            <nav>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location'   =>  'primary-menu',
                        'menu_class'       =>  'flex gap-6 text-sm font-semibold',
                        'container'        =>  'ul'
                    )
                );
            ?>
            </nav>
        </div>
    </header>