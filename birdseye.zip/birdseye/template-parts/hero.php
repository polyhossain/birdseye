<section class="bg-gray-900 py-20">
    <div class="w-8/12 mx-auto">
        <h1 class="text-white text-5xl font-thin capitalize">
            <?php
                if(is_page()) {
                    the_title();
                } else {
                    bloginfo('description');
                }
            ?>
        </h1>
    </div>
</section>