<?php
    get_header();
    the_post();
?>
    <main class="py-6">
        <div class="w-6/12 mx-auto">
            <h1 class="text-4xl font-bold mb-4">
                <?php
                    echo wp_trim_words(get_the_title(), 4, '...');
                ?>
            </h1>

            <div class="flex divide-x gap-1 mb-4 text-gray-600">
                <span class="pr-2 leading-none">
                <?php
                    the_author();
                ?>
                </span>
                <span class="pl-2 leading-none">
                <?php
                    echo get_the_date(); 
                ?>
                </span>
                <span class="pl-2 leading-none">1 min read</span>
            </div>

            <?php
                if(has_post_thumbnail()) {
                    the_post_thumbnail('large', array('class'=>'w-full', 'alt'=>get_the_title()));
                }
            ?>
            <div class="content">
                <?php
                    the_content(); 
                ?>
            </div>
        </div>
    </main>

<?php
    get_footer();