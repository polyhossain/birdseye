<?php
    function birdseye_theme_setup() {
        load_theme_textdomain('birdseye');

        add_theme_support('title-tag');
        add_theme_support('custom-logo');
        add_theme_support('menus');
        add_theme_support('post-thumbnails');

        register_nav_menus(
            array(
                'primary-menu'  =>  __('Primary Menu', 'birdseye'),
                'footer-menu'  =>  __('Footer Menu', 'birdseye')
            )
        );
    }
    add_action('after_setup_theme', 'birdseye_theme_setup');

    function birdseye_theme_assets() {
        //CSS
        wp_enqueue_style('birdseye_css', get_template_directory_uri() . '/assets/css/style.css');

        //JS
        wp_enqueue_script('birdseye_main_stylesheet', '//cdn.tailwindcss.com', null, '1.0.0');
    }
    add_action( 'wp_enqueue_scripts', 'birdseye_theme_assets');


