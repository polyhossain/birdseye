    <footer class="bg-cyan-900 py-3">
        <div class="w-8/12 mx-auto text-white text-sm flex justify-between items-center">
            <p>
                Copyright @ BirdsEye | All Rights Reserved | 2022
            </p>
            <?php
                wp_nav_menu(
                    array(
                        'theme_location'   =>  'footer-menu',
                        'menu_class'       =>  'flex gap-4',
                        'container'        =>  'ul'
                    )
                );
            ?>
        </div>
    </footer>

    <?php
        wp_footer();
    ?>
</body>
</html>