<?php
    get_header();
?>

    <?php
        get_template_part('template-parts/hero');

        if(have_posts()) :
    ?>
    <main class="py-6">
        <div class="w-8/12 mx-auto">
            <div class="grid grid-cols-4 gap-4">
                <?php
                    while(have_posts()) :
                        the_post();
                ?>
                <div class="border rounded-sm shadow-2xl">
                    <a href="<?php the_permalink(); ?>">
                        <?php
                            if(has_post_thumbnail()) {
                                the_post_thumbnail('large', array('class'=>'w-full'));
                            }
                        ?>
                    </a>

                    <div class="p-3">
                        <h3 class="text-lg font-bold">
                            <?php
                                echo wp_trim_words(get_the_title(), 4, '...');
                            ?>
                        </h3>

                        <div class="flex divide-x gap-1 text-xs my-2 text-gray-600">
                            <span class="pr-2 leading-none">
                                <?php
                                    the_author();
                                ?>
                            </span>
                            <span class="pl-2 leading-none">
                                <?php
                                    echo get_the_date(); 
                                ?>
                            </span>
                            <span class="pl-2 leading-none">1 min read</span>
                        </div>

                        <p class="text-sm text-gray-700">
                            <?php
                                echo wp_trim_words(get_the_content(), 20, '...');
                            ?>
                        </p>

                        <a href="<?php the_permalink(); ?>" class="flex gap-1 mt-3 text-sm block font-bold text-cyan-900 group">
                            <?php
                                _e('Read More', 'birdseye');
                            ?> 
                            <span class="hidden group-hover:block">&#8594;</span>
                        </a>
                    </div>
                </div>
                <?php
                    endwhile;
                ?>
            </div>
        </div>
    </main>

<?php
    endif;
    get_footer();
